-- ============================================
-- DB Final Project
-- Student Name:
-- Student ID:
-- DBMS: PostgreSQL
-- ============================================


-- ============================================
-- 1. CREATE TABLE
-- ============================================

CREATE TABLE class_code (
    code  INT PRIMARY KEY,
    class VARCHAR(10),
    basis VARCHAR(20)
);

CREATE TABLE task_code (
    code INT PRIMARY KEY,
    task VARCHAR(30)
);

CREATE TABLE tour_bus (
    bus_id   INT PRIMARY KEY,
    seat     INT,
    del_year INT
);

CREATE TABLE driver (
    driver_id INT PRIMARY KEY,
    name      VARCHAR(20) NOT NULL,
    birthday  CHAR(6)     NOT NULL,
    cell      CHAR(13)    NOT NULL,
    pay       INT         DEFAULT 15000,
    cont_date CHAR(8),
    cont_term CHAR(8)
);

CREATE TABLE customer (
    cus_id VARCHAR(15) PRIMARY KEY,
    name   VARCHAR(20) NOT NULL,
    cell   CHAR(13)    NOT NULL UNIQUE,
    addr   VARCHAR(100),
    c_code INT         DEFAULT 3
);

CREATE TABLE staff (
    staff_id  INT PRIMARY KEY,
    name      VARCHAR(20) NOT NULL,
    birthday  INT         NOT NULL,
    tel       CHAR(12),
    salary    INT,
    t_code    INT         NOT NULL,
    hire_date CHAR(8)     NOT NULL
);

CREATE TABLE tour (
    tour_num  CHAR(8) PRIMARY KEY,
    departure VARCHAR(50) NOT NULL,
    arrival   VARCHAR(50) NOT NULL,
    program   VARCHAR(100),
    start_dt  DATE        NOT NULL,
    end_dt    DATE        NOT NULL,
    min_num   INT,
    max_num   INT,
    expense   INT         NOT NULL,
    deposit   INT,
    dept_yn   CHAR(1)     DEFAULT 'N',
    staff_id  INT REFERENCES staff(staff_id)
);

CREATE TABLE reserve (
    cus_id   VARCHAR(15),
    tour_num CHAR(8),
    res_date CHAR(8) DEFAULT to_char(CURRENT_DATE, 'YYYYMMDD'),
    dep_yn   CHAR(1) DEFAULT 'N',
    exp_yn   CHAR(1) DEFAULT 'N',
    PRIMARY KEY (cus_id, tour_num),
    FOREIGN KEY (cus_id)   REFERENCES customer(cus_id),
    FOREIGN KEY (tour_num) REFERENCES tour(tour_num)
);

CREATE TABLE assign_driver (
    tour_num  CHAR(8) PRIMARY KEY,
    driver_id INT REFERENCES driver(driver_id),
    work_hour INT,
    FOREIGN KEY (tour_num) REFERENCES tour(tour_num)
);

CREATE TABLE assign_bus (
    tour_num CHAR(8) PRIMARY KEY,
    bus_id   INT REFERENCES tour_bus(bus_id),
    FOREIGN KEY (tour_num) REFERENCES tour(tour_num)
);


-- ============================================
-- 2. INSERT DATA
-- ============================================

INSERT INTO class_code VALUES (1, '최우수', '연 5회 이상');
INSERT INTO class_code VALUES (2, '우수',   '연 3회 이상');
INSERT INTO class_code VALUES (3, '일반',   '신규');

INSERT INTO task_code VALUES (1, '여행상품관리');
INSERT INTO task_code VALUES (2, '예약관리');
INSERT INTO task_code VALUES (3, '관광버스배차관리');
INSERT INTO task_code VALUES (4, '직원관리');
INSERT INTO task_code VALUES (5, '고객관리');

INSERT INTO tour_bus VALUES (11, 45, 2019);
INSERT INTO tour_bus VALUES (12, 28, 2020);
INSERT INTO tour_bus VALUES (13, 45, 2021);
INSERT INTO tour_bus VALUES (14, 25, 2018);
INSERT INTO tour_bus VALUES (15, 30, 2022);

INSERT INTO driver VALUES (1001, '김기사', '800312', '010-1111-2222', 15000, '20240101', '12');
INSERT INTO driver VALUES (1002, '이운전', '750820', '010-2222-3333', 16000, '20240201', '24');
INSERT INTO driver VALUES (1003, '박핸들', '820705', '010-3333-4444', 15000, '20230915', '12');
INSERT INTO driver VALUES (1004, '최주행', '900110', '010-4444-5555', 17000, '20240301', '6');
INSERT INTO driver VALUES (1005, '정도로', '781225', '010-5555-6666', 15500, '20231101', '18');

INSERT INTO customer VALUES ('cus001', '홍길동', '010-1234-0001', '서울시 종로구',   1);
INSERT INTO customer VALUES ('cus002', '김영희', '010-1234-0002', '부산시 해운대구', 2);
INSERT INTO customer VALUES ('cus003', '이철수', '010-1234-0003', '대구시 중구',     3);
INSERT INTO customer VALUES ('cus004', '박민수', '010-1234-0004', '인천시 남동구',   3);
INSERT INTO customer VALUES ('cus005', '정수진', '010-1234-0005', '광주시 서구',     2);

INSERT INTO staff VALUES (10001, '강부장', 700101, '010-100-0001', 5000000, 4, '20100301');
INSERT INTO staff VALUES (10002, '윤대리', 850615, '010-100-0002', 3500000, 1, '20150701');
INSERT INTO staff VALUES (10003, '서과장', 800220, '010-100-0003', 4200000, 2, '20120401');
INSERT INTO staff VALUES (10004, '한사원', 920909, '010-100-0004', 3000000, 5, '20200301');
INSERT INTO staff VALUES (10005, '조주임', 880512, '010-100-0005', 3300000, 3, '20180601');

INSERT INTO tour VALUES ('T2026001', '서울', '제주', 'http://tour.com/jeju',      '2026-07-01', '2026-07-03', 10, 30, 450000, 50000, 'N', 10002);
INSERT INTO tour VALUES ('T2026002', '부산', '경주', 'http://tour.com/gyeongju',  '2026-07-05', '2026-07-06', 15, 40, 200000, 30000, 'N', 10002);
INSERT INTO tour VALUES ('T2026003', '서울', '강릉', 'http://tour.com/gangneung', '2026-08-01', '2026-08-02',  8, 25, 180000, 20000, 'N', 10003);
INSERT INTO tour VALUES ('T2026004', '인천', '여수', 'http://tour.com/yeosu',     '2026-08-10', '2026-08-12', 12, 35, 350000, 40000, 'N', 10002);
INSERT INTO tour VALUES ('T2026005', '대구', '제주', 'http://tour.com/jeju2',     '2026-09-01', '2026-09-03', 10, 30, 480000, 50000, 'N', 10003);

INSERT INTO reserve VALUES ('cus001', 'T2026001', '20260601', 'Y', 'N');
INSERT INTO reserve VALUES ('cus002', 'T2026001', '20260602', 'Y', 'Y');
INSERT INTO reserve VALUES ('cus003', 'T2026002', '20260603', 'N', 'N');
INSERT INTO reserve VALUES ('cus001', 'T2026003', '20260604', 'Y', 'N');
INSERT INTO reserve VALUES ('cus004', 'T2026001', '20260605', 'Y', 'N');

INSERT INTO assign_driver VALUES ('T2026001', 1001, 24);
INSERT INTO assign_driver VALUES ('T2026002', 1002, 16);
INSERT INTO assign_driver VALUES ('T2026003', 1003, 16);
INSERT INTO assign_driver VALUES ('T2026004', 1004, 30);
INSERT INTO assign_driver VALUES ('T2026005', 1005, 24);

INSERT INTO assign_bus VALUES ('T2026001', 11);
INSERT INTO assign_bus VALUES ('T2026002', 12);
INSERT INTO assign_bus VALUES ('T2026003', 13);
INSERT INTO assign_bus VALUES ('T2026004', 14);
INSERT INTO assign_bus VALUES ('T2026005', 15);


-- ============================================
-- 3. INDEX
-- ============================================

CREATE INDEX tour_arrival_idx ON tour (arrival ASC);
CREATE INDEX driver_name_idx  ON driver (name ASC);


-- ============================================
-- 4. TEST QUERIES
-- ============================================

-- (1) 고객 등급 검색
SELECT c.name, cc.class
FROM customer c
JOIN class_code cc ON c.c_code = cc.code
WHERE c.cus_id = 'cus001';

-- (2) 직원 담당업무 검색
SELECT s.name, tc.task
FROM staff s
JOIN task_code tc ON s.t_code = tc.code
WHERE s.staff_id = 10002;

-- (3) 여행상품 예약 고객 검색
SELECT c.name, r.res_date, r.dep_yn
FROM reserve r
JOIN customer c ON r.cus_id = c.cus_id
WHERE r.tour_num = 'T2026001';

-- (4) 여행상품 배정 운전기사 검색
SELECT t.departure, d.name, d.cell
FROM tour t
JOIN assign_driver ad ON t.tour_num = ad.tour_num
JOIN driver d         ON ad.driver_id = d.driver_id
WHERE t.tour_num = 'T2026001';

-- (5) 신규 고객 등록 (등급은 DEFAULT 3)
INSERT INTO customer (cus_id, name, cell)
VALUES ('cus006', '신규객', '010-1234-0006');

-- (6) 직원 급여 변경 (20만 원 증가)
UPDATE staff
SET salary = salary + 200000
WHERE staff_id = 10002;

-- (7) 예약 정보 삭제
DELETE FROM reserve
WHERE cus_id = 'cus001' AND tour_num = 'T2026001';

-- ============================================
-- 5. DROP TABLES (생성 역순)
-- ============================================

DROP TABLE assign_bus;
DROP TABLE assign_driver;
DROP TABLE reserve;
DROP TABLE tour;
DROP TABLE staff;
DROP TABLE customer;
DROP TABLE driver;
DROP TABLE tour_bus;
DROP TABLE task_code;
DROP TABLE class_code;